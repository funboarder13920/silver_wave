function [ x0 ] = traceParticle(i,x,u0_i,dt,dx,L)
%UNTITLED9 Summary of this function goes here
%   Detailed explanation goes here
    if (i+1)>length(u0_i)
        r = 1;
    else 
        r= i+1;
    end
    v_x = 1/2*(u0_i(1,i)+u0_i(1,r));
    x0 = dx+mod(x-dt*v_x-dx,L);
end

