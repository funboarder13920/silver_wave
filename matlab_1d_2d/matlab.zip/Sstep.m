function [ s1] = Sstep(s1,s0,kS,aS,u1,Ssource,dt,Ndim)
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here


end

