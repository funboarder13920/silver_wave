Ndim = 2;
L = 100;
dt = 0.1;
N = 10000;
dx = L/N;
visc = 0.0000000001;
kS = 0; aS = 0 ; Ssource = 0;

%F = 1000*(rand(Ndim,N)-0.5);
F = zeros(Ndim,N);
F(1,1:10) = 1;

% vecteur vitesse, u0 �tape n-1, u1 �tape n
u0 = zeros(Ndim,N);
u1 = zeros(Ndim,N);
x = dx*0.5 + linspace(0,L,N);

% substance transport�e par le flux
s0 = zeros(Ndim,N);
s1 = zeros(Ndim,N);

i = 1;
figure
while 1
    % handle display and user interaction
    % get forces F and sources Ssource from th UI
    x=mod(x+dt*u1,L);
    %u1(5)
    %x(5)
    %x(12)
    [u0,u1] = swap(u0,u1);
    [s0,s1] = swap(s0,s1);
    u1 = Vstep(u1,u0,visc,F,dt,Ndim,dx,L);
    Sstep(s1,s0,kS,aS,u1,Ssource,dt,Ndim);
    plot(i*dt,x(1,5),'r')
    hold on
    plot(i*dt,x(1,12),'b')
    hold on
    drawnow
    if i > 100
        F = (rand(Ndim,N)-0.2);
    end
    i=i+1;
end