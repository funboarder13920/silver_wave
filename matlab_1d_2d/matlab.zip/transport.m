function [ u1_i] = transport(u1_i,u0_i,u0,dt,dx,L)
%UNTITLED8 Summary of this function goes here
%   Detailed explanation goes here
    for i=1:length(u1_i)
        x = dx+mod(dx*(i-0.5)-dx,L);
        x0 = traceParticle(i,x,u0,dt,dx,L);
        u1_i(1,i) = linInterp(x0,u0_i,dx);
    end
    %u1_i(1,5)
    %u1_i(1,4)
    %u1_i(1,11)
end

