function [ u1_i ] = linInterp(x0,u0,dx)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    inv_x0 = 1+mod(x0/dx+ 0.5 -1 , length(u0)-1);
    i_x0 = fix(inv_x0);
    r_x0 = max(0,inv_x0 - double(i_x0));
    if i_x0+1 > length(u0)
        r = 1;
    else
        r = i_x0+1;
    end
    u1_i = (1-r_x0)*u0(1,i_x0) + r_x0*u0(1,r);
end

